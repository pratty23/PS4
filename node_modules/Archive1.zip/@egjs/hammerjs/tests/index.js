import {Manager, Pan, Pinch, DIRECTION_NONE, DIRECTION_VERTICAL, DIRECTION_HORIZONTAL, DIRECTION_ALL, PointerEventInput, TouchMouseInput, TouchInput, MouseInput} from "../src/index";

console.log(Manager, Pan, Pinch, PointerEventInput, TouchMouseInput, TouchInput, MouseInput, DIRECTION_NONE, DIRECTION_VERTICAL, DIRECTION_HORIZONTAL, DIRECTION_ALL);


export default {};
