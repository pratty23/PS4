# json-file [![CircleCI](https://circleci.com/gh/expo/json-file.svg?style=svg)](https://circleci.com/gh/expo/json-file)

A library for reading and writing JSON files.
