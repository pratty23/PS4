# plist [![CircleCI](https://circleci.com/gh/expo/plist.svg?style=svg)](https://circleci.com/gh/expo/plist)

Mac OS X Plist parser/builder for Node.js and browsers, forked from this [repo](https://github.com/TooTallNate/plist.js)
