import FontAwesome5 from './build/FontAwesome5';
export default FontAwesome5;
