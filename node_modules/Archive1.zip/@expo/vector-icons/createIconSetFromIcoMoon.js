import createIconSetFromIcoMoon from './build/createIconSetFromIcoMoon';
export default createIconSetFromIcoMoon;
